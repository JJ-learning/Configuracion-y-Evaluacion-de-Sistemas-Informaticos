<?php
    class cronometro {
      var $comienzo;

      function getMicrotime() {
          list($milisegundos, $segundos) = explode(" ", microtime());
          return ( (float) $milisegundos + (float) $segundos );
      }

      # constructor cronometro
      function cronometro() {
          $this->comienzo = $this->getMicrotime();
          return true;
      }

      # para el cronometro y devuelve el tiempo
      # se puede dar una salida formateada a traves de los parametros.
      # Si $formatear esta a verdadero entonces devolvera cuantos segundos
      # se demoro con $nroDecimales decimales (milisegundos).
      function stop($formatear = false, $nroDecimales = 0) {
          $tiempo = $this->getMicrotime() - $this->comienzo;
          return ( $formatear ) ? number_format( $tiempo, $nroDecimales, ',', '.') : $tiempo;
      }
    }
 ?>


<?php
  $link = mysqli_connect("localhost", "root", "root");
  mysqli_select_db($link, "CESI");
  if (!$link) {
      echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
      echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
      echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
      exit;
  }

  $tildes = $link->query("SET NAMES 'utf8'"); //Para que se inserten las tildes correctamente

  function microtime_float(){
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
  }

  $salida = shell_exec ('ps -p 8454 -o %cpu,%mem');
  echo "<pre>$salida</pre>";
  //$time = -microtime(true);
  //$time_general = microtime(true);
  $tiempoG = new cronometro();
  $tiempo1 = new cronometro();
  for ($i=0; $i < 50000; $i++) {
    //$time_start0_10000 = microtime(true);
    //mysqli_query($link, "UPDATE `agenda` SET `Nombre`='a'");
    mysqli_query($link, "INSERT INTO agenda VALUES ('Pepe', 'Rodriguez', 'Calle', '699887766', 35, 14008)");
    if($i == 5000){
      echo $tiempo1->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo2 = new cronometro();
    }
    if($i == 10000){
      echo $tiempo2->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo3 = new cronometro();
    }
    if($i == 15000){
      echo $tiempo3->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo4 = new cronometro();
    }
    if($i == 20000){
      echo $tiempo4->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo5 = new cronometro();
    }
    if($i == 25000){
      echo $tiempo5->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo6 = new cronometro();
    }
    if($i == 30000){
      echo $tiempo6->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo7 = new cronometro();
    }
    if($i == 35000){
      echo $tiempo7->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo8 = new cronometro();
    }
    if($i == 40000){
      echo $tiempo8->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo9 = new cronometro();
    }
    if($i == 45000){
      echo $tiempo9->stop( true, 4 );
      $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
      echo "<pre>$salida</pre>";
      $tiempo10 = new cronometro();
    }
    echo "iterations:$i";
    echo '<br>';
  }

  echo $tiempo10->stop( true, 4 );
  $salida = shell_exec ('ps -p 1721 -o %cpu,%mem');
  echo "<pre>$salida</pre>";
  echo "El general:";
  echo $tiempoG->stop( true, 4 );
  //$time_general = microtime(true);
  //$time = $time_general - $time_general;
  //echo "ha tardado $time";
  echo '<br>';
  //$time += microtime(true);
  //echo "iterations:$i time: ",sprintf('%f', $time),PHP_EOL;
  mysqli_close($link); // Cerramos la conexion con la base de datos
  echo 'Los datos han sido insertados en la base de datos';

?>
